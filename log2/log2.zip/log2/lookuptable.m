TABLEWIDTH = 7;
FRACWIDTH = 5;
log2_frac = zeros(1, 2^TABLEWIDTH);
log2_frac_integer = zeros(1, 2^TABLEWIDTH);
for i = 0:2^TABLEWIDTH-1
    log2_frac(i+1) = log2((i+2^7)/2^7);
    log2_frac_integer(i+1) = round(log2_frac(i+1)*2^FRACWIDTH);
    if(log2_frac_integer(i+1) == 2^FRACWIDTH)
        log2_frac_integer(i+1) = 2^FRACWIDTH - 1;
    end
end

fid = fopen('frac.txt','wt');
fprintf(fid,'%x\n',log2_frac_integer);
fclose(fid);